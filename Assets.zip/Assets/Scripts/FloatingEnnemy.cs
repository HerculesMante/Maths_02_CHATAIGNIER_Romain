using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using Unity.VisualScripting;

[RequireComponent(typeof(Rigidbody2D))]
public class FloatingEnnemy : MonoBehaviour
{
    [SerializeField] private float _oscillationAmplitude = 0.0f;
    [SerializeField] private float _oscillationFrequency = 0.0f;

    private Vector3 _basePosition = Vector3.zero;

    private void Awake()
    {
        _basePosition = transform.position;
    }

    private void Update()
    {
        float oscillation = Mathf.Sin(Time.time * _oscillationFrequency);
        oscillation = (oscillation + 1.0f) / 2.0f;
        oscillation *= _oscillationAmplitude;
        transform.position = _basePosition + new Vector3(oscillation, 0.0f, 0.0f);
    }
}

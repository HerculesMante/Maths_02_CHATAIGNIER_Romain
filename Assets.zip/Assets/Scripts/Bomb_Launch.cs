using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using Unity.VisualScripting;

public class Bomb_Launch : MonoBehaviour
{
    public float touch_ground = 0.0f;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (touch_ground == 2.0f)
        {
            Destroy(gameObject);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        Ground ground = collision.GetComponent<Ground>();

        if (ground != null)
            touch_ground = touch_ground + 1.0f;
    }
}
